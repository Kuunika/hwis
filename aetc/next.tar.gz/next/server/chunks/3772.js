"use strict";exports.id=3772,exports.ids=[3772],exports.modules={57316:(r,e,t)=>{t.d(e,{X:()=>o});var a=t(10326),i=t(41905),n=t(46226);let o=({error:r,onPrimaryAction:e,onSecondaryAction:t})=>(0,a.jsxs)(i.y3,{sx:{display:"flex",alignItems:"center",flexDirection:"column",justifyContent:"center"},children:[a.jsx(n.default,{width:150,height:150,src:"/error.png",alt:"error"}),a.jsx("br",{}),(0,a.jsxs)(i.YS,{variant:"body2",children:["Error occurred whilst ",a.jsx("strong",{children:r})]}),a.jsx("br",{}),(0,a.jsxs)(i.y3,{sx:{display:"flex"},children:[a.jsx(i.c7,{onClick:e,title:"retry",sx:{mr:"0.5ch"}}),a.jsx(i.c7,{onClick:t,title:"cancel",variant:"secondary"})]})]})},17278:(r,e,t)=>{t.d(e,{Q:()=>E});var a=t(10326),i=t(17577),n=t(91703),o=t(71728),l=t(91367),s=t(45353),d=t(41135),c=t(18782),u=t(8106),f=t(11190),b=t(93244),m=t(54641),h=t(54117),v=t(44647),p=t(36004);function g(r){return(0,p.ZP)("MuiLinearProgress",r)}let x=(0,v.Z)("MuiLinearProgress",["root","colorPrimary","colorSecondary","determinate","indeterminate","buffer","query","dashed","dashedColorPrimary","dashedColorSecondary","bar","barColorPrimary","barColorSecondary","bar1Indeterminate","bar1Determinate","bar1Buffer","bar2Indeterminate","bar2Buffer"]),y=["className","color","value","valueBuffer","variant"],Z=r=>r,C,j,k,P,$,w,S=(0,u.F4)(C||(C=Z`
  0% {
    left: -35%;
    right: 100%;
  }

  60% {
    left: 100%;
    right: -90%;
  }

  100% {
    left: 100%;
    right: -90%;
  }
`)),I=(0,u.F4)(j||(j=Z`
  0% {
    left: -200%;
    right: 100%;
  }

  60% {
    left: 107%;
    right: -8%;
  }

  100% {
    left: 107%;
    right: -8%;
  }
`)),B=(0,u.F4)(k||(k=Z`
  0% {
    opacity: 1;
    background-position: 0 -23px;
  }

  60% {
    opacity: 0;
    background-position: 0 -23px;
  }

  100% {
    opacity: 1;
    background-position: -200px -23px;
  }
`)),q=r=>{let{classes:e,variant:t,color:a}=r,i={root:["root",`color${(0,m.Z)(a)}`,t],dashed:["dashed",`dashedColor${(0,m.Z)(a)}`],bar1:["bar",`barColor${(0,m.Z)(a)}`,("indeterminate"===t||"query"===t)&&"bar1Indeterminate","determinate"===t&&"bar1Determinate","buffer"===t&&"bar1Buffer"],bar2:["bar","buffer"!==t&&`barColor${(0,m.Z)(a)}`,"buffer"===t&&`color${(0,m.Z)(a)}`,("indeterminate"===t||"query"===t)&&"bar2Indeterminate","buffer"===t&&"bar2Buffer"]};return(0,c.Z)(i,g,e)},D=(r,e)=>"inherit"===e?"currentColor":r.vars?r.vars.palette.LinearProgress[`${e}Bg`]:"light"===r.palette.mode?(0,f.$n)(r.palette[e].main,.62):(0,f._j)(r.palette[e].main,.5),L=(0,n.ZP)("span",{name:"MuiLinearProgress",slot:"Root",overridesResolver:(r,e)=>{let{ownerState:t}=r;return[e.root,e[`color${(0,m.Z)(t.color)}`],e[t.variant]]}})(({ownerState:r,theme:e})=>(0,s.Z)({position:"relative",overflow:"hidden",display:"block",height:4,zIndex:0,"@media print":{colorAdjust:"exact"},backgroundColor:D(e,r.color)},"inherit"===r.color&&"buffer"!==r.variant&&{backgroundColor:"none","&::before":{content:'""',position:"absolute",left:0,top:0,right:0,bottom:0,backgroundColor:"currentColor",opacity:.3}},"buffer"===r.variant&&{backgroundColor:"transparent"},"query"===r.variant&&{transform:"rotate(180deg)"})),M=(0,n.ZP)("span",{name:"MuiLinearProgress",slot:"Dashed",overridesResolver:(r,e)=>{let{ownerState:t}=r;return[e.dashed,e[`dashedColor${(0,m.Z)(t.color)}`]]}})(({ownerState:r,theme:e})=>{let t=D(e,r.color);return(0,s.Z)({position:"absolute",marginTop:0,height:"100%",width:"100%"},"inherit"===r.color&&{opacity:.3},{backgroundImage:`radial-gradient(${t} 0%, ${t} 16%, transparent 42%)`,backgroundSize:"10px 10px",backgroundPosition:"0 -23px"})},(0,u.iv)(P||(P=Z`
    animation: ${0} 3s infinite linear;
  `),B)),R=(0,n.ZP)("span",{name:"MuiLinearProgress",slot:"Bar1",overridesResolver:(r,e)=>{let{ownerState:t}=r;return[e.bar,e[`barColor${(0,m.Z)(t.color)}`],("indeterminate"===t.variant||"query"===t.variant)&&e.bar1Indeterminate,"determinate"===t.variant&&e.bar1Determinate,"buffer"===t.variant&&e.bar1Buffer]}})(({ownerState:r,theme:e})=>(0,s.Z)({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left",backgroundColor:"inherit"===r.color?"currentColor":(e.vars||e).palette[r.color].main},"determinate"===r.variant&&{transition:"transform .4s linear"},"buffer"===r.variant&&{zIndex:1,transition:"transform .4s linear"}),({ownerState:r})=>("indeterminate"===r.variant||"query"===r.variant)&&(0,u.iv)($||($=Z`
      width: auto;
      animation: ${0} 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite;
    `),S)),z=(0,n.ZP)("span",{name:"MuiLinearProgress",slot:"Bar2",overridesResolver:(r,e)=>{let{ownerState:t}=r;return[e.bar,e[`barColor${(0,m.Z)(t.color)}`],("indeterminate"===t.variant||"query"===t.variant)&&e.bar2Indeterminate,"buffer"===t.variant&&e.bar2Buffer]}})(({ownerState:r,theme:e})=>(0,s.Z)({width:"100%",position:"absolute",left:0,bottom:0,top:0,transition:"transform 0.2s linear",transformOrigin:"left"},"buffer"!==r.variant&&{backgroundColor:"inherit"===r.color?"currentColor":(e.vars||e).palette[r.color].main},"inherit"===r.color&&{opacity:.3},"buffer"===r.variant&&{backgroundColor:D(e,r.color),transition:"transform .4s linear"}),({ownerState:r})=>("indeterminate"===r.variant||"query"===r.variant)&&(0,u.iv)(w||(w=Z`
      width: auto;
      animation: ${0} 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) 1.15s infinite;
    `),I)),F=i.forwardRef(function(r,e){let t=(0,h.Z)({props:r,name:"MuiLinearProgress"}),{className:i,color:n="primary",value:o,valueBuffer:c,variant:u="indeterminate"}=t,f=(0,l.Z)(t,y),m=(0,s.Z)({},t,{color:n,variant:u}),v=q(m),p=(0,b.V)(),g={},x={bar1:{},bar2:{}};if(("determinate"===u||"buffer"===u)&&void 0!==o){g["aria-valuenow"]=Math.round(o),g["aria-valuemin"]=0,g["aria-valuemax"]=100;let r=o-100;p&&(r=-r),x.bar1.transform=`translateX(${r}%)`}if("buffer"===u&&void 0!==c){let r=(c||0)-100;p&&(r=-r),x.bar2.transform=`translateX(${r}%)`}return(0,a.jsxs)(L,(0,s.Z)({className:(0,d.Z)(v.root,i),ownerState:m,role:"progressbar"},g,{ref:e},f,{children:["buffer"===u?(0,a.jsx)(M,{className:v.dashed,ownerState:m}):null,(0,a.jsx)(R,{className:v.bar1,ownerState:m,style:x.bar1}),"determinate"===u?null:(0,a.jsx)(z,{className:v.bar2,ownerState:m,style:x.bar2})]}))});var N=t(41905);let X=(0,n.ZP)(F)(({theme:r})=>({height:10,borderRadius:5,[`&.${x.colorPrimary}`]:{backgroundColor:r.palette.grey["light"===r.palette.mode?200:800]},[`& .${x.bar}`]:{borderRadius:5,backgroundColor:r.palette.primary}}));function E({message:r,progress:e}){return(0,a.jsxs)(o.Z,{sx:{flexGrow:1},children:[a.jsx(X,{variant:"determinate",value:e}),a.jsx(N.YS,{fontStyle:"italic",children:r})]})}},58204:(r,e,t)=>{t.d(e,{s:()=>s});var a=t(10326),i=t(71728),n=t(30274),o=t(5753),l=t(41905);function s({title:r,primaryActionText:e,secondaryActionText:t,onPrimaryAction:s,onSecondaryAction:d,printButton:c}){return a.jsx(i.Z,{display:"flex",alignItems:"center",justifyContent:"center",width:"100%",children:(0,a.jsxs)(i.Z,{display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",children:[a.jsx(n.Z,{variant:"h1",color:"green",children:a.jsx(o.ETl,{})}),a.jsx(n.Z,{variant:"h5",fontWeight:"500",children:r}),(0,a.jsxs)(i.Z,{mt:"2ch",sx:{display:"flex"},children:[a.jsx(l.c7,{onClick:s,title:e}),a.jsx(l.c7,{variant:"secondary",sx:{ml:"0.5ch"},onClick:d,title:t}),c]})]})})}},75859:(r,e,t)=>{t.d(e,{b:()=>c,Z:()=>u});var a=t(23814),i=t(59239);let n="visits",o=r=>(0,i.Ue)(r,n),l=(r,e)=>(0,i.eP)(r,e,n);var s=t(44976),d=t(10119);let c=()=>{let r=(0,s.NL)();return(0,d.D)({mutationFn:r=>o(r).then(r=>r.data),onSuccess:e=>{r.invalidateQueries({queryKey:["visits"]})}})},u=()=>(0,d.D)({mutationFn:r=>l(r,{stopDatetime:(0,a.Fc)()}).then(r=>r.data)})},57481:(r,e,t)=>{t.r(e),t.d(e,{default:()=>i});var a=t(66621);let i=r=>[{type:"image/x-icon",sizes:"305x298",url:(0,a.fillMetadataSegment)(".",r.params,"favicon.ico")+""}]}};